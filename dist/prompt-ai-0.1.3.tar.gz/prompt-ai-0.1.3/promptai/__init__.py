from .prompt_ai import generate
from .prompt_ai import configure
